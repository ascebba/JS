function one_key_press() {
  alert("Hai premuto un tasto quando eri dentro la casella (one key press)");
}

function one_key_down() {
  alert("Hai premuto un tasto quando eri dentro la casella (one key down)");
}

function one_key_up() {
  alert("Hai premuto un tasto quando eri dentro la casella (one key up)");
}

/*Tip: The order of events related to the onkeyup event:
1. onkeydown
2. onkeypress
3. onkeyup
*/
