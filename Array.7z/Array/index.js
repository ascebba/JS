//metodi dell'oggetto Array

var array_di_prova = new Array("a","b","c","d");  //inizializzazione
var array_di_prova_2 = ["a","b","c"];             //altro tipo di inizializzazione
var array_di_prova_1 = new Array(5);              //non inizializzato


var size = array_di_prova_1.length;
document.write ("Lunghezza: " + size + "<br>");   //size = 5;

for ( var i = 0; i < size; i++ ){   //i < 5
  array_di_prova_1[i] = i;
}

 //0,1,2,3,4
document.write(array_di_prova_1 + "<br>");


//METODI PRINCIPALI DELL'OGGETTO Array

//concat
document.write("test di concat: <br>");
var a = new Array (1, 2, 3);
var b = new Array (4, 5, 6);
var c = a.concat(b); //1, 2, 3, 4, 5, 6
document.write(c + "<br>");
c = b.concat(a);
document.write(c + "<br>");    //4,5,6,1,2,3

//sort
document.write("test di sort: <br>");
var a = new Array ("d", "a", "e", "t", "f");
a = a.sort();
document.write(a + "<br>"); //a,d,e,f,t

var a = new Array ("d", "a", "e", "T", "f");
a = a.sort();
document.write(a + "<br>"); //T,a,d,e,f   le maiuscole vanno prima

//reverse
document.write("test di reverse: <br>");
var a = new Array ("A", "E", "I", "O", "U");
a.reverse();
document.write(a + "<br>"); //U,O,I,E,A

//slice
document.write("test di reverse: <br>");
var a = new Array ("A", "E", "I", "O", "U");
a = a.slice(0,3); //taglia il vettore a dall'indice 0 all'indice 3 (l'ultimo elemento non viene incluso, il primo si)
document.write(a + "<br>"); //A,E,I


//ITERARE GLI ELEMENTI DI UN Array
document.write("iterare un array: <br>");
var a = new Array ("A", "E", "I", "O", "U");


document.write("prova di for in: <br>");
for (var i in a) {                           // for in
  document.write(a[i] + " ");               //A E I O U
}
document.write("<br>");


document.write("prova di for of: <br>");
const iterable = [10, 20, 30];
for (const value of iterable) {             //for of
  document.write(value + " ");              //10 20 30
}
document.write("<br>");


document.write("prova di foreach: <br>");
var a = [ 1, 2, 3, 4, 5, 6 ];
a.forEach( item => document.write(item)); //ad ogni iterazione chiama una funzione che ha tre argomenti: il valore dell'elemento, l'indice dell'elemento, l'oggetto array che deve essere processato
document.write("<br>");
























//prova
