function on_focus(elem){
  elem.style.background = "red";
  elem.style.color = "white";
}

function on_blur(elem){
  elem.style.background = "white";
  elem.style.color = "red";
}

function selezione() {
  var x = document.getElementById("mySelect").value;
  document.getElementById("demo").innerHTML = "You selected: " + x;
}
