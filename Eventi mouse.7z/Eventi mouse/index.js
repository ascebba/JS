//eventi del mouse

document.getElementById("demo").onmousedown = function() {prova_omd()};
document.getElementById("demo").onmouseup = function() {prova_omu()};

//on click
function prova_oc(){
  alert("tasto cliccato una volta");
}

//on double click
function prova_odc(){
  alert("tasto cliccato due volte");
}

//on mouse up
function prova_omu(){
  alert("Hover tasto in");
}

//on mouse down
function prova_omd(){
  document.write("byby");
}

//on mouse over
function prova_omo(element,colore) {
  this.style.color = colore;
}

function cambia_colore(elmnt,colore) {
  elmnt.style.color = colore;
}

function mouseOver() {
  document.getElementById("demo2").style.color = "red";
}


//on mouse out
function mouseOut() {
  document.getElementById("demo2").style.color = "black";
}


//on mouse move
document.getElementById("myDIV").onmousemove = function(event) {myFunction(event)};

function myFunction(e) {
  var x = e.clientX;
  var y = e.clientY;
  var coor = "Coordinate: (" + x + "," + y + ")";
  document.getElementById("demo").innerHTML = coor;
}







/*function mouseDown() {
  document.getElementById("demo").innerHTML = "The mouse button is held down.";
}

function mouseUp() {
  document.getElementById("demo").innerHTML = "You released the mouse button.";
}*/
