/*window.defaultStatus = "Testo personalizzato";
oppure anche
defaultStatus = "Testo personalizzato";

window.status = "Testo personalizzato";
status = "Testo personalizzato";
*/                                              //molti browser non li usano più quindi non si raccomanda di usarli

function funzione_apertura(){
  var question = confirm("sei sicuro di voler aprire una nuova pagina? ");
  if (question == true)
    window.open("index2.html","","scrollbars=no; location=no");    //url interno alla cartella dove giace il file, parametri
    //la finestra si chiudera in automatico perchè è stato inserito il metodo close() che può essere chiamato solo in una finestra aperta tramite lo script window.open()
}


/*confirm:
fa aprire una finestra con un testo scritto e fa selezionare due opzioni: ok oppure annulla.
restituisce true se viene cliccato ok, false altrimenti */


var risultato = confirm("Sei sicuro di voler proseguire?");
risultato == true ? alert("hai deciso di proseguire") : alert("hai deciso di non proseguire");

//alert
alert("hello");

//prompt
var frase = prompt("Scrivi la frase che vuoi inserire: ");
document.write(frase);    //frase inserita dentro il prompt*

//blur: toglie il focus dalla finestra del browser
window.blur();
document.write("blur eseguito <br>");

//focus: mette il focus nella finestra del browser
window.focus();
document.write("focus eseguito <br>");

//open: apre una nuova finestra nel browser
window.open();
document.write("open eseguito <br>");


funzione_apertura();
